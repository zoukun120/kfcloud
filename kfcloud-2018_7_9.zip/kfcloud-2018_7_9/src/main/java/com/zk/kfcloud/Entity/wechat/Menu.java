package com.zk.kfcloud.Entity.wechat;

public class Menu {
    private Button[] button;// 数据类型（引用数据类型即类名)[] 数组名；

    public Button[] getButton() {
        return button;
    }

    public void setButton(Button[] button) {
        this.button = button;
    }


}
