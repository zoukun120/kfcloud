package com.zk.kfcloud.Entity.wechat;

public class ClickButton extends Button {
    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

}
