package com.zk.kfcloud.Entity.web;

import java.util.Date;

public class KF0002_Alarm {
    Date time;
    Boolean alarm01;
    Boolean alarm02;
    Boolean alarm03;
    Boolean alarm04;
    Boolean alarm05;
    Boolean alarm06;
    Boolean alarm07;
    Boolean alarm08;
    Boolean alarm09;
    Boolean alarm10;
    Boolean alarm11;
    Boolean alarm12;
    Boolean alarm13;
    Boolean alarm14;
    Boolean alarm15;
    Boolean alarm16;

    @Override
    public String toString() {
        return "KF0002_Alarm{" +
                "time=" + time +
                ", alarm01=" + alarm01 +
                ", alarm02=" + alarm02 +
                ", alarm03=" + alarm03 +
                ", alarm04=" + alarm04 +
                ", alarm05=" + alarm05 +
                ", alarm06=" + alarm06 +
                ", alarm07=" + alarm07 +
                ", alarm08=" + alarm08 +
                ", alarm09=" + alarm09 +
                ", alarm10=" + alarm10 +
                ", alarm11=" + alarm11 +
                ", alarm12=" + alarm12 +
                ", alarm13=" + alarm13 +
                ", alarm14=" + alarm14 +
                ", alarm15=" + alarm15 +
                ", alarm16=" + alarm16 +
                '}';
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public Boolean getAlarm01() {
        return alarm01;
    }

    public void setAlarm01(Boolean alarm01) {
        this.alarm01 = alarm01;
    }

    public Boolean getAlarm02() {
        return alarm02;
    }

    public void setAlarm02(Boolean alarm02) {
        this.alarm02 = alarm02;
    }

    public Boolean getAlarm03() {
        return alarm03;
    }

    public void setAlarm03(Boolean alarm03) {
        this.alarm03 = alarm03;
    }

    public Boolean getAlarm04() {
        return alarm04;
    }

    public void setAlarm04(Boolean alarm04) {
        this.alarm04 = alarm04;
    }

    public Boolean getAlarm05() {
        return alarm05;
    }

    public void setAlarm05(Boolean alarm05) {
        this.alarm05 = alarm05;
    }

    public Boolean getAlarm06() {
        return alarm06;
    }

    public void setAlarm06(Boolean alarm06) {
        this.alarm06 = alarm06;
    }

    public Boolean getAlarm07() {
        return alarm07;
    }

    public void setAlarm07(Boolean alarm07) {
        this.alarm07 = alarm07;
    }

    public Boolean getAlarm08() {
        return alarm08;
    }

    public void setAlarm08(Boolean alarm08) {
        this.alarm08 = alarm08;
    }

    public Boolean getAlarm09() {
        return alarm09;
    }

    public void setAlarm09(Boolean alarm09) {
        this.alarm09 = alarm09;
    }

    public Boolean getAlarm10() {
        return alarm10;
    }

    public void setAlarm10(Boolean alarm10) {
        this.alarm10 = alarm10;
    }

    public Boolean getAlarm11() {
        return alarm11;
    }

    public void setAlarm11(Boolean alarm11) {
        this.alarm11 = alarm11;
    }

    public Boolean getAlarm12() {
        return alarm12;
    }

    public void setAlarm12(Boolean alarm12) {
        this.alarm12 = alarm12;
    }

    public Boolean getAlarm13() {
        return alarm13;
    }

    public void setAlarm13(Boolean alarm13) {
        this.alarm13 = alarm13;
    }

    public Boolean getAlarm14() {
        return alarm14;
    }

    public void setAlarm14(Boolean alarm14) {
        this.alarm14 = alarm14;
    }

    public Boolean getAlarm15() {
        return alarm15;
    }

    public void setAlarm15(Boolean alarm15) {
        this.alarm15 = alarm15;
    }

    public Boolean getAlarm16() {
        return alarm16;
    }

    public void setAlarm16(Boolean alarm16) {
        this.alarm16 = alarm16;
    }
}
